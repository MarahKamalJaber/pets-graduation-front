import 'package:flutter/material.dart';

class EditProfile extends StatefulWidget {
  @override
  _EditProfile createState() {
    return _EditProfile();
  }
}

class _EditProfile extends State<EditProfile> {
  @override
  Widget build(BuildContext context) {
    return Text("Edit Profile");
  }
}
